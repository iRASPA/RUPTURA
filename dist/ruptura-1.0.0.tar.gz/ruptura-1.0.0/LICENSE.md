The MIT License (MIT)

Copyright (c) 2023 Shrinjay Sharma, Salvador Rodríguez-Gómez Balestra, 
                   Richard Baur, Umang Agarwal, Erik Zuidema, Marcello Rigutto,
                   Sofia Calero, Thijs Vlugt, David Dubbeldam
 
 S.Sharma-6@tudelft.nl      https://nl.linkedin.com/in/shrinjay-sharma
 salrodgom@upo.es           http://salrodgom.github.io/
 Richard.Baur@shell.com     
 U.Agarwal@shell.com        https://www.linkedin.com/in/umang-agarwal-31672b22
 Erik.Zuidema@shell.com     https://nl.linkedin.com/in/erik-zuidema-a9168614
 marcello.rigutto@shell.com https://nl.linkedin.com/in/marcello-rigutto-66581620
 S.Calero@tue.nl            https://www.tue.nl/en/research/researchers/sofia-calero/
 t.j.h.vlugt@tudelft.nl     http://homepage.tudelft.nl/v9k6y
 D.Dubbeldam@uva.nl         https://www.uva.nl/en/profile/d/u/d.dubbeldam/d.dubbeldam.html

 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
