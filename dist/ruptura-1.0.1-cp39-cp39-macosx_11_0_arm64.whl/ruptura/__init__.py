from .ruptura import *
